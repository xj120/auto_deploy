package com.processmining.logdeploy.autodeploy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoDeployApplicationTests {

    @Test
    void contextLoads() {
    }

}
