package com.processmining.logdeploy.autodeploy.entity;

public class Format {

    public static final String COMMON = "common";
    public static final String ZIP = ".zip";
    public static final String TAR_GZ = ".tar.gz";

}
